import os
import re
import subprocess

from docparser.base import APIDocConverter
from docparser.utils import file2html, dict2json, top_level_split, decode


def normalize(func):
    def inner(*args):
        ret = func(*args)
        if isinstance(ret, (set, list, tuple)):
            return [r if not isinstance(r, str) else decode(r.replace("  ", " ")) for r in ret]
        if isinstance(ret, str):
            return decode(ret.replace("  ", " "))
        return ret
    return inner


def index(arr, item):
    try:
        return arr.index(item)
    except ValueError:
        return None

def or_index(arr):
    for i in arr:
        if i is not None:
            return i
    return None


def and_index(arr):
    for i in arr:
        if i is None:
            return False
    return True


class JarAPIDocConverter(APIDocConverter):
    INCLUDE_MAP = {
        "rt.jar": re.compile("^java/"),
        "android-13.jar": re.compile("^android/"),
        "joda-time-2.0.jar": re.compile("^org/joda/time/"),
        "gwt-user.jar": re.compile("[/\\w]*/gwt/"),
        "gwt-servlet-1.4.62.jar": re.compile("[/\\w]*/gwt/"),
        "gwt-dev-2.9.0.jar": re.compile("[/\\w]*/gwt/"),
        "hibernate-3.5.3.jar": re.compile("^org/hibernate/"),
        "hibernate-annotations.jar": re.compile("^org/hibernate/"),
        "hibernate-shards.jar": re.compile("^org/hibernate/"),
        "hibernate-validator.jar": re.compile("^org/hibernate/"),
        "xstream-1.4.4.jar": re.compile("^com/thoughtworks/xstream/"),
    }
    EXCLUDED_FILES = [
        # 'package-summary.html',
        # 'package-tree.html',
        # 'package-use.html',
        # 'package-frame.html'
    ]
    PROTECTED = "protected"
    PUBLIC = "public"

    def __init__(self, args):
        super().__init__()

    @normalize
    def extract_class_name(self, javap_output):
        parts = javap_output[0].split()
        cls_index = or_index([index(parts, "class"), index(parts, "interface"), index(parts, "enum")])
        if cls_index is None:
            raise Exception(f"Cannot find extract class name: {parts}")

        regex = re.compile("([@A-Za-z0-9\\.\\_]+).*")
        text = parts[cls_index+1].replace("$", ".")
        if text.endswith("."):
            return None, None
        match = re.match(regex, text)
        if not match:
            raise Exception("Cannot extract class name: {!r}".format(text))
        return match.group(1), " ".join([text[len(match.group(1)):], *parts[cls_index+2:]])

    @normalize
    def extract_class_type_parameters(self, rest_name):
        rest_name = rest_name.replace(", ", ",")

        if not rest_name.startswith("<"):
            return [], rest_name
        splits = top_level_split(rest_name, separator=" ")
        return top_level_split(splits[0][1:-1]), " ".join(splits[1:])

    @normalize
    def extract_super_class(self, rest_type_parameters):
        text = rest_type_parameters.replace("$", ".").replace("\n", " ").replace("  ", " ").replace(", ", ",").replace(" {", "")
        regex2 = re.compile("[^\\s]* ?extends (.*)( implements .*)?")
        match = re.match(regex2, text)
        if not match:
            return []
        text = match.group(1).split(" implements ")[0]

        return top_level_split(text)

    def extract_class_type(self, javap_output):
        text = javap_output[0]
        if 'interface' in text:
            return self.INTERFACE
        if 'abstract class' in text:
            return self.ABSTRACT_CLASS
        if 'abstract static class' in text:
            return self.ABSTRACT_CLASS
        if 'enum' in text:
            return self.ENUM
        return self.REGULAR_CLASS

    def extract_class_access_modifier(self, javap_output):
        parts = javap_output[0].split()

        text = parts[0]
        if "protected" == text:
            return "protected"
        if "public" == text:
            return "public"
        return None

    @normalize
    def extract_super_interfaces(self, rest_type_parameters):
        text = rest_type_parameters.replace("$", ".").replace("\n", " ").replace("  ", " ").replace(", ", ",").replace(" {", "")
        segs = text.split(" implements ")
        if len(segs) == 1:
            return []
        text = segs[1].replace(", ", ",")
        return top_level_split(text)

    @normalize
    def extract_functional_interface(self, class_url):
        javap_result = subprocess.run(['javap', '-public', '-constants', '-v', class_url], capture_output=True, text=True)
        if javap_result.returncode != 0:
            print(f"Error checking is_annotation {class_url}: {javap_result.stderr}")
            return True
        lines = javap_result.stdout.splitlines()
        lines = lines[lines.index("Constant pool:")]
        constants = list()
        for line in lines:
            if not line.strip().startswith("#"):
                break
            constants.append(line.split()[-1])
        return and_index([index(constants, "RuntimeVisibleAnnotations"), index(constants, "Ljava/lang/FunctionalInterface")])

    def is_class_static(self, javap_output):
        parts = javap_output[0].split()
        cls_index = or_index([index(parts, "class"), index(parts, "interface"), index(parts, "enum")])
        if cls_index is None:
            raise Exception("Cannot find extract class name: {!r}".format(javap_output[0]))

        return "static" in parts[:cls_index]

    @normalize
    def extract_parent_class(self, javap_output):
        parts = javap_output[0].split()
        cls_index = or_index([index(parts, "class"), index(parts, "interface"), index(parts, "enum")])
        if cls_index is None:
            raise Exception("Cannot find extract class name: {!r}".format(javap_output[0]))

        text = parts[cls_index+1]

        is_static = self.is_class_static(javap_output)
        if "$" in text and not is_static:
            regex = re.compile("([@A-Za-z0-9\\.\\_]+).*")
            match = re.match(regex, text)
            if not match:
                raise Exception("Cannot extract class name: {!r}".format(text))
            class_name = match.group(1)
            return class_name.split(".")[-1]
        return None


    def is_annotation(self, class_url):
        javap_result = subprocess.run(['javap', '-public', '-constants', '-v', class_url], capture_output=True, text=True)
        if javap_result.returncode != 0:
            print(f"Error checking is_annotation {class_url}: {javap_result.stderr}")
            return True
        flags = list(filter(lambda l: l.strip().startswith("flags: (0x"), javap_result.stdout.splitlines()))
        if len(flags) > 0:
            return "ACC_ANNOTATION" in flags[0]
        return True


    def is_enum(self, javap_output):
        return javap_output[0].find("java.lang.Enum") != -1

    def process(self, args):
        input_path = os.path.normpath(args.input)
        if not os.path.isfile(input_path):
            return
        result = subprocess.run(['jar', 'tf', input_path], capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error listing contents of {input_path}: {result.stderr}")
            return
        classes = [line for line in result.stdout.splitlines() if line.endswith('.class')]
        for class_file in classes:
            if class_file in self.EXCLUDED_FILES:
                continue
            if os.path.basename(input_path) in self.INCLUDE_MAP:
                if re.match(self.INCLUDE_MAP[os.path.basename(input_path)], class_file) is None:
                    continue
            class_url = f"jar:file://{os.path.abspath(input_path)}!/{class_file}"
            print(f"Running javap on {class_url}...")
            javap_result = subprocess.run(['javap', '-public', class_url], capture_output=True, text=True)
            if javap_result.returncode != 0:
                print(f"Error listing contents of {class_url}: {javap_result.stderr}")
                return
            if self.is_annotation(class_url):
                continue

            data = self.process_class(javap_result.stdout.splitlines()[:-1], class_url, lambda name: os.path.exists(os.path.join(args.output, name) + ".json"))
            if data:
                data["language"] = "java"
            print(data)
            dict2json(args.output, data)

    def maybe_object(self, super_class, class_type, class_name):
        if len(super_class) == 0 and class_type is not self.INTERFACE and class_name != "java.lang.Object":
            return ["java.lang.Object"]
        return super_class

    @staticmethod
    def not_static_block(s):
        return s != "static {};"

    @staticmethod
    def is_field(s):
        parts = s.replace(", ", ",").split(" throws ")[0].split("=", 1)
        if len(parts) > 1:
            return True
        if "(" in parts[-1] and ")" in parts[-1]:
            return False
        return True

    @staticmethod
    def is_method(s):
        return not JarAPIDocConverter.is_field(s)

    @staticmethod
    def is_constructor(s, class_name):
        return JarAPIDocConverter.is_method(s) and s.endswith(";") and s.find(")") != -1 and len(list(filter(lambda part: part.replace("$", ".").startswith(class_name + "("), s.split()))) == 1

    def extract_methods(self, javap_output, class_type, class_name):
        constructors = list()
        methods = list()
        for method in filter(JarAPIDocConverter.is_method, map(lambda a: a.strip(), javap_output[1:])):
            if JarAPIDocConverter.is_constructor(method, class_name):
                if class_type is self.ABSTRACT_CLASS:
                    continue
                constructors.append(method)
            else:
                methods.append(method)
        return methods, constructors

    def extract_fields(self, javap_output):
        return list(filter(JarAPIDocConverter.not_static_block, filter(JarAPIDocConverter.is_field, map(lambda a: a.strip(), javap_output[1:]))))

    def process_class(self, data, class_url, exist_f):
        javap_output = data
        if data[0].startswith("Compiled from "):
            javap_output = data[1:]
        class_name, rest_name = self.extract_class_name(javap_output)
        if not class_name:
            # TODO handle annotations
            return None
        if class_name.split(".")[-1].isnumeric():
            # Anon classes
            return None
        if exist_f(class_name):
            return None
        if self.is_enum(javap_output):
            return None

        # self._cls_name = class_name
        type_parameters, rest_type_parameters = self.extract_class_type_parameters(rest_name)
        # type_parameters = [type_param.replace(f" {class_name}<",
        #                                       f" {full_class_name}<")
        #                    for type_param in type_parameters]
        super_class = self.extract_super_class(rest_type_parameters)
        super_interfaces = self.extract_super_interfaces(rest_type_parameters)
        class_type = self.extract_class_type(javap_output)
        super_class = self.maybe_object(super_class, class_type, class_name)
        access_mod = self.extract_class_access_modifier(javap_output)
        if access_mod is None:
            return None
        is_func_interface = self.extract_functional_interface(class_url)
        if class_type == self.ENUM:
            # TODO handle enums
            return None
        # self._current_api_cls = html_doc
        methods, constructors = self.extract_methods(javap_output, class_type, class_name)
        fields = self.extract_fields(javap_output)
        print(fields)
        print(constructors)
        print(methods)
        method_objs = self.process_methods(methods, False)
        method_objs.sort(key=lambda m: m['name'])
        constructor_objs = self.process_methods(constructors, True)
        field_objs = self.process_fields(fields)

        parent = self.extract_parent_class(javap_output)
        class_obj = {
          'name': class_name,
          'type_parameters': type_parameters,
          'implements': super_interfaces,
          'inherits': super_class,
          "class_type": class_type,
          'methods': method_objs + constructor_objs,
          'fields': field_objs,
          "functional_interface": is_func_interface,
          "parent": parent,
          "access_mod": access_mod,
        }
        return class_obj

    @normalize
    def extract_method_type_parameters(self, method_doc, is_constructor):
        if is_constructor:
            return method_doc.strip(), []
        # regex = re.compile(r"(<(.*)>)?[^<>,\[\]\?](.*)?(\[\])?")
        text = method_doc.replace("  ", " ").replace(
                    "\n", " ").replace("static ", "").replace(
                        "default ", "").replace("abstract ", "").replace(
                            "protected ", "").replace("final ", "").replace(
                                "synchronized ", "").replace(
                                    "public ", "").replace(
                                        "native ", "").strip()
        # match = re.match(regex, text)
        if text.startswith("<") and text.endswith(">"):
            return method_doc[:len(text)].strip(), top_level_split(text[1:-1])
        if text.startswith("<") ^ text.endswith(">"):
            raise Exception("Cannot match method's signature {!r}".format(
                method_doc))
        return method_doc.strip(), []

    @normalize
    def extract_method_return_type(self, method_doc, is_constructor):
        if is_constructor:
            return method_doc.replace(", ", ","), None

        parts = top_level_split(method_doc, separator=" ")
        return " ".join(parts[:-1]), parts[-1].replace("$", ".")

    def _replace_anchors_with_package_prefix(self, anchors):
        # This method replaces the text of all anchors (note that the text
        # corresponds to type names) with the fully quallified name of the
        # type. The package prefix is found in a attribute of each anchor
        # named "title".
        for anchor in anchors:
            if anchor.string is None:
                continue
            if anchor.string.startswith("@"):
                # Ignore annotations
                if anchor.string not in ["@FunctionalInterface", "@interface"]:
                    anchor.string.replace_with("")
                continue
            title = anchor.get("title")
            if not title or "type parameter" in title:
                # It's either a primitive type of a type parameter. We ignore
                # them.
                continue
            package_prefix = title.split(" in ")[1]
            if not anchor.string.startswith(package_prefix):
                anchor.string.replace_with(package_prefix + "." + anchor.text)

    def _extract_key_for_parameter_types(self, method_doc, is_constructor):
        if self.new_javadoc:
            key = ".col-second code"
            return key
        if self.jdk_docs:
            key = ".colConstructorName code" if is_constructor else \
                ".colSecond code"
        else:
            key = (".colOne code"
                   if is_constructor else ".colSecond code")
        if not is_constructor and not self.jdk_docs:
            if method_doc.find(class_="colSecond") is None:
                key = ".colLast code"
        return key

    @normalize
    def extract_method_parameter_types(self, method_doc):
        if method_doc.startswith("(") and method_doc.endswith(")"):
            return top_level_split(method_doc[1:-1].replace("$", "."))
        raise Exception(f"Error parsing method_doc {method_doc}")

    def extract_method_access_mod(self, method_doc, is_con):
        method_doc = method_doc.strip()
        if method_doc.startswith(self.PROTECTED):
            return self.PROTECTED
        if method_doc.startswith(self.PUBLIC):
            return self.PUBLIC
        return None

    @normalize
    def extract_method_name(self, method_doc, is_constructor):
        parts = method_doc.split()
        for part_i in range(0, len(parts)):
            part = parts[part_i]
            if "(" in part:
                if is_constructor:
                    return " ".join(parts[:part_i]), " ".join([part[part.index("("):]] + parts[part_i+1:]), part[:part.index("(")].replace("$", ".").split(".")[-1]
                return " ".join(parts[:part_i]), " ".join([part[part.index("("):]] + parts[part_i+1:]), part[:part.index("(")]
        return None, None, None

    def extract_isstatic(self, method_doc, is_constructor):
        if is_constructor:
            return False
        return 'static' in method_doc.split()

    def extract_isdefault(self, method_doc, is_constructor):
        if is_constructor:
            return False
        return 'default' in method_doc.split()

    def extract_exceptions(self, method_doc):
        parts = method_doc.split(" throws ", 1)
        if len(parts) > 1:
            return parts[0].strip(), parts[1].replace("$", ".").split(", ")
        return parts[0].strip(), []

    @normalize
    def extract_field_name(self, field_doc):
        parts = field_doc.split(" = ", 1)
        first_part = parts[0]
        if len(parts) > 1:
            first_part = parts[1]
        first_part_parts = first_part.split()
        return " ".join(first_part_parts[:-1]), first_part_parts[-1]

    @normalize
    def extract_field_type(self, field_doc):
        return self.extract_method_return_type(field_doc, False)

    def extract_field_access_mod(self, field_doc):
        return self.extract_method_access_mod(field_doc, False)

    def process_methods(self, methods, is_con):
        method_objs = []
        for method_doc in methods:
            pre_exceptions, exceptions = self.extract_exceptions(method_doc[:-1])
            pre_method_name, post_method_name, method_name = self.extract_method_name(pre_exceptions, is_con)
            # print(f"pre m n {pre_method_name}")
            # print(f"post m n {post_method_name}")
            # print(f"m n {method_name}")
            if method_name is None:
                raise Exception("Cannot parse method name")
            pre_ret_type, ret_type = self.extract_method_return_type(pre_method_name, is_con)
            # print(f"pre ret {pre_ret_type}")
            pre_type_param, type_params = self.extract_method_type_parameters(pre_ret_type, is_con)
            # print(f"pre tp {pre_type_param}")
            param_types = self.extract_method_parameter_types(post_method_name)
            access_mod = self.extract_method_access_mod(pre_type_param, is_con)
            if access_mod is None:
                continue
            is_default = self.extract_isdefault(pre_type_param, is_con)
            isstatic = self.extract_isstatic(pre_type_param, is_con)

            if param_types is None:
                # It's either a field, or a nested class
                continue
            method_obj = {
                "name": method_name,
                "parameters": param_types,
                "type_parameters": type_params,
                "return_type": ret_type,
                "is_static": isstatic,
                "is_constructor": is_con,
                "access_mod": access_mod,
                "throws": exceptions,
                "is_default": is_default
            }
            method_objs.append(method_obj)
        return method_objs

    def process_fields(self, fields):
        field_objs = []
        for field_doc in fields:
            pre_name, field_name = self.extract_field_name(field_doc[:-1].strip())
            pre_ret_type, field_type = self.extract_field_type(pre_name)
            access_mod = self.extract_field_access_mod(pre_ret_type)
            isstatic = self.extract_isstatic(field_doc, False)
            if access_mod is None:
                continue

            field_obj = {
                "name": field_name,
                "type": field_type,
                "is_static": isstatic,
                "access_mod": access_mod
            }
            field_objs.append(field_obj)
        return field_objs
